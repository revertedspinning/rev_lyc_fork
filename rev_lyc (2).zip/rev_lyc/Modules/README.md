# Boilerplate code
```lua
---Module function.
---@param self Defender
---@param timing Timing
return function(self, timing)
end
```