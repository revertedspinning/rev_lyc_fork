-- GameTab module.
local GameTab = {}

---@module Features.Game.Spoofing
local Spoofing = require("Features/Game/Spoofing")

---@module Utility.Configuration
local Configuration = require("Utility/Configuration")

---@module Utility.Logger
local Logger = require("Utility/Logger")

---@module Game.KeyHandling
local KeyHandling = require("Game/KeyHandling")

-- Services.
local players = game:GetService("Players")

---@module Features.Game.Tweening
local Tweening = require("Features/Game/Tweening")

---Initialize local character section.
---@param groupbox table
function GameTab.initLocalCharacterSection(groupbox)
	local speedHackToggle = groupbox:AddToggle("Speedhack", {
		Text = "Speedhack",
		Tooltip = "Modify your character's velocity while moving.",
		Default = false,
	})

	speedHackToggle:AddKeyPicker("SpeedhackKeybind", { Default = "N/A", SyncToggleState = true, Text = "Speedhack" })

	local speedDepBox = groupbox:AddDependencyBox()

	speedDepBox:AddSlider("SpeedhackSpeed", {
		Text = "Speedhack Speed",
		Default = 200,
		Min = 0,
		Max = 300,
		Suffix = "/s",
		Rounding = 0,
	})

	local cframeSpeedToggle = groupbox:AddToggle("CFrameSpeed", {
		Text = "CFrame Speed",
		Tooltip = "Use CFrame-based movement. Recommend on low speed, this feature will help your fight and make your combo/movement smoother.",
		Default = false,
	})

	cframeSpeedToggle:AddKeyPicker("CFrameSpeedKeybind", { Default = "N/A", SyncToggleState = true, Text = "CFrame Speed" })

	local cfsDepBox = groupbox:AddDependencyBox()

	cfsDepBox:AddSlider("CFrameSpeedMultiplier", {
		Text = "CFrame Speed Multiplier",
		Default = 1,
		Min = 1,
		Max = 20,
		Suffix = "x",
		Rounding = 1,
	})

	local flyToggle = groupbox:AddToggle("Fly", {
		Text = "Fly",
		Tooltip = "Set your character's velocity while moving to imitate flying.",
		Default = false,
	})

	flyToggle:AddKeyPicker("FlyKeybind", { Default = "N/A", SyncToggleState = true, Text = "Fly" })

	local flyDepBox = groupbox:AddDependencyBox()

	flyDepBox:AddSlider("FlySpeed", {
		Text = "Fly Speed",
		Default = 200,
		Min = 0,
		Max = 450,
		Suffix = "/s",
		Rounding = 0,
	})

	flyDepBox:AddSlider("FlyUpSpeed", {
		Text = "Spacebar Fly Speed",
		Default = 150,
		Min = 0,
		Max = 450,
		Suffix = "/s",
		Rounding = 0,
	})

	local noclipToggle = groupbox:AddToggle("NoClip", {
		Text = "NoClip",
		Tooltip = "Disable collision(s) for your character.",
		Default = false,
	})

	noclipToggle:AddKeyPicker("NoClipKeybind", { Default = "N/A", SyncToggleState = true, Text = "NoClip" })

	local noclipDepBox = groupbox:AddDependencyBox()

	noclipDepBox:AddToggle("NoClipCollisionsKnocked", {
		Text = "Collisions While Knocked",
		Tooltip = "Enable collisions while knocked.",
		Default = false,
	})

	local ttbToggle = groupbox:AddToggle("TweenToBack", {
		Text = "Tween To Back",
		Tooltip = "Start following the nearest entity based on a distance and height offset.",
		Default = false,
		Callback = function(state)
			if state then
				return
			end

			Tweening.stop("TweenToBack")
		end,
	})

	ttbToggle:AddKeyPicker("TweenToBackKeybind", { Default = "N/A", SyncToggleState = true, Text = "Tween To Back" })

	local ttbDepBox = groupbox:AddDependencyBox()

	ttbDepBox:AddToggle("StickyAttach", {
		Text = "Sticky Attach",
		Tooltip = "Continue following the entity until it dies.",
		Default = false,
	})

	ttbDepBox:AddToggle("AttachIgnorePlayers", {
		Text = "Ignore Players",
		Tooltip = "Do not attach to players.",
		Default = true,
	})

	ttbDepBox:AddSlider("BackOffset", {
		Text = "Distance To Entity",
		Default = 5,
		Min = -100,
		Max = 100,
		Suffix = "studs",
		Rounding = 0,
	})

	ttbDepBox:AddSlider("HeightOffset", {
		Text = "Height Offset",
		Default = 0,
		Min = -100,
		Max = 30,
		Suffix = "studs",
		Rounding = 0,
	})

	local infJumpToggle = groupbox:AddToggle("InfiniteJump", {
		Text = "Infinite Jump",
		Tooltip = "Boost your velocity while the jump key is held.",
		Default = false,
	})

	infJumpToggle:AddKeyPicker(
		"InfiniteJumpKeybind",
		{ Default = "N/A", SyncToggleState = true, Text = "Infinite Jump" }
	)

	local infiniteJumpDepBox = groupbox:AddDependencyBox()

	infiniteJumpDepBox:AddSlider("InfiniteJumpBoost", {
		Text = "Infinite Jump Boost",
		Default = 50,
		Min = 0,
		Max = 500,
		Suffix = "/s",
		Rounding = 0,
	})

	groupbox:AddToggle("AgilitySpoof", {
		Text = "Agility Spoofer",
		Tooltip = "Set your Agility investment points to boost movement.",
		Default = false,
	})

	local agilitySpoofDepBox = groupbox:AddDependencyBox()

	agilitySpoofDepBox:AddToggle("BoostAgilityDirectly", {
		Text = "Boost Agility Directly",
		Tooltip = "Boost your Agility directly instead of using investment points.",
		Default = false,
	})

	agilitySpoofDepBox:AddSlider("AgilitySpoof", {
		Text = "Agility Value",
		Default = 0,
		Min = 0,
		Max = 400,
		Suffix = "pts",
		Rounding = 0,
	})

	groupbox:AddToggle("AutoSprint", {
		Text = "Auto Sprint",
		Tooltip = "Instantly invoke a sprint when pressing a key in any direction.",
		Default = false,
	})

	local asDepBox = groupbox:AddDependencyBox()

	asDepBox:AddToggle("AutoSprintOnCrouch", {
		Text = "Auto Sprint On Crouch",
		Tooltip = "Allow 'Auto Sprint' to run even while crouching.",
		Default = false,
	})

	asDepBox:AddToggle("AutoSprintDelay", {
		Text = "Auto Sprint Delay",
		Tooltip = "Delay the automated sprint activation after pressing a key.",
		Default = false,
	})

	local asdDepBox = asDepBox:AddDependencyBox()

	asdDepBox:AddSlider("AutoSprintDelayTime", {
		Text = "Auto Sprint Delay Time",
		Default = 0.2,
		Min = 0,
		Max = 5,
		Suffix = "s",
		Rounding = 2,
	})

	groupbox:AddToggle("FreestylersBandSpoof", {
		Text = "Freestylers Band Spoofer",
		Tooltip = "Use the Freestylers Band without equipping it.",
		Default = false,
	})

	groupbox:AddToggle("KongaClutchRingSpoof", {
		Text = "Konga Clutch Ring Spoofer",
		Tooltip = "Use the Konga Clutch Ring without equipping it.",
		Default = false,
	})

	groupbox:AddToggle("EmoteSpoofer", {
		Text = "Emote Spoofer",
		Tooltip = "Unlock all emotes and use them without owning them.",
		Default = false,
	})

	groupbox:AddToggle("MaxMomentumSpoof", {
		Text = "Max Momentum Spoofer",
		Tooltip = "Spoof your character's momentum to the maximum value.",
		Default = false,
	})

	groupbox:AddButton({
		Text = "Respawn Character",
		DoubleClick = true,
		Func = function()
			local character = players.LocalPlayer.Character
			if not character then
				return
			end

			local humanoidRootPart = character:FindFirstChild("HumanoidRootPart")
			if not humanoidRootPart then
				return
			end

			character:PivotTo(humanoidRootPart.CFrame * CFrame.new(0, 10000000, 0))
		end,
	})

	groupbox:AddButton({
		Text = "Deal Fall Damage To Self",
		DoubleClick = true,
		Func = function()
			local remote = KeyHandling.getRemote("FallDamage")
			if not remote then
				return Logger.notify("Failed to find fall damage remote.")
			end

			remote:FireServer(Configuration.expectOptionValue("FallDamageAmount") or 0.0, false)
		end,
	})

	groupbox:AddSlider("FallDamageAmount", {
		Text = "Fall Damage Amount",
		Default = 50,
		Min = 0,
		Max = 1000,
		Suffix = "hp",
		Rounding = 0,
	})

	agilitySpoofDepBox:SetupDependencies({
		{ Toggles.AgilitySpoof, true },
	})

	asdDepBox:SetupDependencies({
		{ Toggles.AutoSprintDelay, true },
	})

	asDepBox:SetupDependencies({
		{ Toggles.AutoSprint, true },
	})

	infiniteJumpDepBox:SetupDependencies({
		{ Toggles.InfiniteJump, true },
	})

	speedDepBox:SetupDependencies({
		{ Toggles.Speedhack, true },
	})

	cfsDepBox:SetupDependencies({
		{ Toggles.CFrameSpeed, true },
	})

	flyDepBox:SetupDependencies({
		{ Toggles.Fly, true },
	})

	noclipDepBox:SetupDependencies({
		{ Toggles.NoClip, true },
	})

	ttbDepBox:SetupDependencies({
		{ Toggles.TweenToBack, true },
	})
end

---Initialize player monitoring section.
---@param groupbox table
function GameTab.initPlayerMonitoringSection(groupbox)
	groupbox:AddToggle("NotifyMod", {
		Text = "Mod Notifications",
		Default = true,
	})

	local nmDepBox = groupbox:AddDependencyBox()

	nmDepBox:AddToggle("NotifyModSound", {
		Text = "Mod Notification Sound",
		Tooltip = "Use a sound along with the mod notification.",
		Default = false,
	})

	local nmbDepBox = nmDepBox:AddDependencyBox()

	nmbDepBox:AddSlider("NotifyModSoundVolume", {
		Text = "Sound Volume",
		Default = 10,
		Min = 0,
		Max = 20,
		Suffix = "v",
		Rounding = 2,
	})

	nmbDepBox:SetupDependencies({
		{ Toggles.NotifyModSound, true },
	})

	nmDepBox:SetupDependencies({
		{ Toggles.NotifyMod, true },
	})

	groupbox:AddToggle("NotifyVoidWalker", {
		Text = "Void Walker Notifications",
		Tooltip = "This will notify you when a player has a Void Walker contract.",
		Default = false,
	})

	local niToggle = groupbox:AddToggle("NotifyItems", {
		Text = "Item Notifications",
		Tooltip = "This will notify you when a player has any listed item in their inventory.",
		Default = false,
	})

	local niDepBox = groupbox:AddDependencyBox()

	local notifyItemsList = niDepBox:AddDropdown("NotifyItemsList", {
		Text = "Item List",
		Default = {},
		SaveValues = true,
		Multi = true,
		Values = {},
	})

	local itemLabel = niDepBox:AddInput("NotifyItemsLabel", {
		Text = "Item Name",
		Placeholder = "Partial or exact item name.",
	})

	niDepBox:AddButton("Add Name To Filter", function()
		local itemLabelValue = itemLabel.Value

		if #itemLabelValue <= 0 then
			return Logger.notify("Please enter a valid item name.")
		end

		local notifyItemsListValues = notifyItemsList.Values

		if not table.find(notifyItemsListValues, itemLabelValue) then
			table.insert(notifyItemsListValues, itemLabelValue)
		end

		notifyItemsList:SetValues(notifyItemsListValues)
		notifyItemsList:SetValue({})
		notifyItemsList:Display()
	end)

	niDepBox:AddButton("Remove Selected Names", function()
		local notifyItemsListValues = notifyItemsList.Values
		local selectedNotifyItems = notifyItemsList.Value

		for selectedNotifyItem, _ in next, selectedNotifyItems do
			local selectedIndex = table.find(notifyItemsListValues, selectedNotifyItem)
			if not selectedIndex then
				return Logger.notify("The selected item name %s does not exist in the list", selectedNotifyItem)
			end

			table.remove(notifyItemsListValues, selectedIndex)
		end

		notifyItemsList:SetValues(notifyItemsListValues)
		notifyItemsList:SetValue({})
		notifyItemsList:Display()
	end)

	niDepBox:SetupDependencies({
		{ niToggle, true },
	})

	groupbox:AddToggle("PlayerSpectating", {
		Text = "Player List Spectating",
		Tooltip = "Click on a player on the player list to spectate them.",
		Default = false,
	})

	groupbox:AddToggle("BuildStealer", {
		Text = "Build Stealer",
		Tooltip = "Steal builds by hovering on them in the player list and pressing 'P' on your keyboard.",
		Default = false,
	})

	groupbox:AddToggle("ShowHiddenPlayers", {
		Text = "Show Hidden Players",
		Tooltip = "Show hidden players on the player list.",
		Default = false,
	})

	groupbox:AddToggle("ShowRobloxChat", {
		Text = "Show Roblox Chat",
		Default = false,
	})

	groupbox:AddToggle("ShowOwnership", {
		Text = "Show Network Ownership",
		Default = false,
	})

	groupbox:AddToggle("PlayerProximity", {
		Text = "Player Proximity Notifications",
		Tooltip = "When other players are within specified distance, notify the user.",
		Default = false,
	})

	local ppDepBox = groupbox:AddDependencyBox()

	ppDepBox:AddSlider("PlayerProximityRange", {
		Text = "Player Proximity Distance",
		Default = 1000,
		Min = 50,
		Max = 2500,
		Suffix = "studs",
		Rounding = 0,
	})

	ppDepBox:AddToggle("PlayerProximityVW", {
		Text = "Only Allow Voidwalkers",
		Tooltip = "The other players must have a Voidwalker Contract for us to be warned.",
		Default = false,
	})

	ppDepBox:AddToggle("PlayerProximityBeep", {
		Text = "Play Beep Sound",
		Tooltip = "Use a beep sound along with the proximity notification.",
		Default = false,
	})

	local ppbDepBox = ppDepBox:AddDependencyBox()

	ppbDepBox:AddSlider("PlayerProximityBeepVolume", {
		Text = "Beep Sound Volume",
		Default = 0.1,
		Min = 0,
		Max = 10,
		Suffix = "v",
		Rounding = 2,
	})

	ppbDepBox:SetupDependencies({
		{ Toggles.PlayerProximityBeep, true },
	})

	ppDepBox:SetupDependencies({
		{ Toggles.PlayerProximity, true },
	})
end

---Initialize effect removals section.
---@param groupbox table
function GameTab.initEffectRemovalsSection(groupbox)
	groupbox:AddToggle("NoStun", {
		Text = "No Stun",
		Tooltip = "Remove any incoming 'Stun' effects from the server.",
		Default = false,
	})

	groupbox:AddToggle("NoSpeedDebuff", {
		Text = "No Speed Debuff",
		Tooltip = "Remove any incoming 'Speed Debuff' effects from the server.",
		Default = false,
	})

	local noFallToggle = groupbox:AddToggle("NoFallDamage", {
		Text = "No Fall Damage",
		Tooltip = "Remove any 'Fall Damage' requests to the server.",
		Default = false,
	})

	noFallToggle:AddKeyPicker(
		"NoFallDamageKeybind",
		{ Default = "N/A", SyncToggleState = true, Text = "No Fall Damage" }
	)

	groupbox:AddToggle("NoAcidWater", {
		Text = "No Acid Water",
		Tooltip = "Remove any 'Acid Water Damage' requests to the server.",
		Default = false,
	})

	groupbox:AddToggle("NoWind", {
		Text = "No Wind",
		Tooltip = "Remove any 'Wind' effects from the server.",
		Default = false,
	})

	groupbox:AddToggle("NoAttackingClientChecks", {
		Text = "No Attacking Client Checks",
		Default = false,
		Tooltip = "Remove any 'Attacking' effects from the server.",
	})

	groupbox:AddToggle("AlwaysAllowJump", {
		Text = "Always Allow Jump",
		Tooltip = "Remove any 'No Jump' effects from the server.",
		Default = false,
	})
end

---Initialize instance removals.
---@param groupbox table
function GameTab.initInstanceRemovalsSection(groupbox)
	groupbox:AddToggle("NoEchoModifiers", {
		Text = "No Echo Modifiers",
		Tooltip = "Remove any 'Echo Modifiers' instances on the client.",
		Default = false,
	})

	groupbox:AddToggle("NoKillBricks", {
		Text = "No Kill Bricks",
		Tooltip = "Remove any 'Kill Brick' parts on the client.",
		Default = false,
	})

	groupbox:AddToggle("NoDamageBricks", {
		Text = "No Damage Bricks",
		Tooltip = "Disable any 'Damage Brick' parts on the client.",
		Default = false,
	})

	groupbox:AddToggle("NoCastleLightBarrier", {
		Text = "No Castle Light Barrier",
		Tooltip = "Remove any 'Castle Light Barrier' parts on the client.",
		Default = false,
	})

	groupbox:AddToggle("NoYunShulBarrier", {
		Text = "No Yun Shul Barrier",
		Tooltip = "Remove any 'Yun Shul Barrier' parts on the client.",
		Default = false,
	})

	groupbox:AddToggle("NoHiveGate", {
		Text = "No Hive Gate",
		Tooltip = "Remove any 'Hive Gate' parts on the client.",
		Default = false,
	})
end

---Debugging section.
---@param groupbox table
function GameTab.initDebuggingSection(groupbox)
	groupbox:AddToggle("ShowDebugInformation", {
		Text = "Show Debug Information",
		Default = false,
	})

	groupbox:AddToggle("EffectLogging", {
		Text = "Effect Logging",
		Default = false,
	})

	groupbox:AddToggle("StopGameLogging", {
		Text = "Stop Game Logging",
		Default = false,
	})
end

---Info spoofing section.
---@param groupbox table
function GameTab.initInfoSpoofingSection(groupbox)
	local hasEverBeenEnabled = true

	groupbox:AddToggle("InfoSpoofing", {
		Text = "Enable Info Spoofing",
		Default = false,
		Callback = function(value)
			-- Only refresh if we've ever enabled this feature or we're currently enabling it.
			if value or hasEverBeenEnabled then
				Spoofing.rics()
			end

			-- We don't need to mark if we're disabling it.
			if not value then
				return
			end

			-- Spoof UI.
			Spoofing.sss(Configuration.expectOptionValue("SpoofedSlotString"))
			Spoofing.sds(Configuration.expectOptionValue("SpoofedDateString"))
			Spoofing.sgv(Configuration.expectOptionValue("SpoofedGameVersion"))

			-- Mark that we've enabled this atleast once...
			hasEverBeenEnabled = true
		end,
	})

	local isDepBox = groupbox:AddDependencyBox()

	isDepBox:AddToggle("SpoofOtherPlayers", {
		Text = "Spoof Other Players",
		Default = false,
		Callback = Spoofing.rics,
	})

	isDepBox:AddToggle("HideDeathInformation", {
		Text = "Hide Death Information",
		Default = false,
	})

	isDepBox:AddInput("SpoofedSlotString", {
		Text = "Spoofed Slot String",
		Default = "1234567890:Z|1 [Lv. 1]",
		Finished = true,
		Callback = Spoofing.sss,
	})

	isDepBox:AddInput("SpoofedDateString", {
		Text = "Spoofed Date String",
		Default = "Linoria, 1970 CE",
		Finished = true,
		Callback = Spoofing.sds,
	})

	isDepBox:AddInput("SpoofedGameVersion", {
		Text = "Spoofed Game Version",
		Default = "pv_JAN_01_00:00z",
		Finished = true,
		Callback = Spoofing.sgv,
	})

	local function refreshHandler()
		if not Configuration.expectToggleValue("InfoSpoofing") then
			return
		end

		Spoofing.rics()
	end

	isDepBox:AddInput("SpoofedFirstName", {
		Text = "Spoofed First Name",
		Default = "Linoria V2",
		Finished = true,
		Callback = refreshHandler,
	})

	isDepBox:AddInput("SpoofedLastName", {
		Text = "Spoofed Last Name",
		Default = "On Top",
		Finished = true,
		Callback = refreshHandler,
	})

	isDepBox:AddInput("SpoofedGuildName", {
		Text = "Spoofed Guild Name",
		Default = "discord.gg/lyc",
		Finished = true,
		Callback = refreshHandler,
	})

	isDepBox:AddInput("SpoofedServerName", {
		Text = "Spoofed Server Name",
		Default = "Linoria V2",
		Finished = true,
		Callback = refreshHandler,
	})

	isDepBox:AddInput("SpoofedServerRegion", {
		Text = "Spoofed Server Region",
		Default = "discord.gg/lyc",
		Finished = true,
		Callback = refreshHandler,
	})

	isDepBox:AddInput("SpoofedServerAge", {
		Text = "Spoofed Server Age",
		Default = "???",
		Finished = true,
		Callback = refreshHandler,
	})

	isDepBox:SetupDependencies({
		{ Toggles.InfoSpoofing, true },
	})
end

---Tweening section.
---@param groupbox table
function GameTab.initTweeningSection(groupbox)
	groupbox:AddSlider("TweenStudsPerSecond", {
		Text = "Tween Speed",
		Default = 200,
		Min = 50,
		Max = 450,
		Suffix = "/s",
		Rounding = 0,
	})
end

---Initialize tab.
function GameTab.init(window)
	-- Create tab.
	local tab = window:AddTab("Game")

	-- Initialize sections.
	GameTab.initDebuggingSection(tab:AddDynamicGroupbox("Debugging"))
	GameTab.initLocalCharacterSection(tab:AddDynamicGroupbox("Local Character"))
	GameTab.initEffectRemovalsSection(tab:AddDynamicGroupbox("Effect Removals"))
	GameTab.initInstanceRemovalsSection(tab:AddDynamicGroupbox("Instance Removals"))
	GameTab.initPlayerMonitoringSection(tab:AddDynamicGroupbox("Player Monitoring"))
	GameTab.initInfoSpoofingSection(tab:AddDynamicGroupbox("Info Spoofing"))
	GameTab.initTweeningSection(tab:AddDynamicGroupbox("Tweening Customization"))
end

-- Return GameTab module.
return GameTab
